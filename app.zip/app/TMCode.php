<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TMCode extends Model
{
    protected $guarded = [];
    protected $table = 'tm_codes';
}
