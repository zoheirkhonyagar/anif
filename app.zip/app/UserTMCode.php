<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTMCode extends Model
{
    protected $guarded = [];
    protected $table = 'user_tm_code';
}
