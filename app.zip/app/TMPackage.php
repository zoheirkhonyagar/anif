<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TMPackage extends Model
{
    protected $guarded = [];
    protected $table = 'tm_package';
}
