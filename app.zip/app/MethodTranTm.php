<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MethodTranTm extends Model
{
    protected $guarded = [];
    protected $table = 'methods_tran_tm';
}
