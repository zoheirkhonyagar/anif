<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TMTransaction extends Model
{
    protected $guarded = [];
    protected $table = 'tm_transactions';
}
