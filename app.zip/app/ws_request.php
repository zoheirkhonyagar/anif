<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ws_request extends Model
{
    protected $guarded = [];
}
