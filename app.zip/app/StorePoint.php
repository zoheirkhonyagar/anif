<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StorePoint extends Model
{
    protected $guarded = [];


    public function store()
    {
        return $this->belongsTo(Store::class, 'store_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function comment()
    {
        return $this->hasMany(Comment::class);
    }
}
