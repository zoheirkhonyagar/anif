<div class="row-content offers">
    <h2 class="title">تخفیف های آنیف</h2>
    <div class="items offer-items">
        <?php $__currentLoopData = $sortedWithOff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item offer-item">
                <div class="image-box">
                    <a href="#"><img src="/img/offer-item.jpeg" alt="image-box"></a>
                    <span class="offer-percent">تا <?php echo e($store->max_off); ?>٪</span>
                </div>
                <div class="caption-box">
                    <div class="logo">
                        <img src="/img/item-logo.png" alt="لوگو">
                    </div>
                    <div class="info">
                        <div class="title"><a href="#"><?php echo e($store->name); ?></a></div>
                        <div class="location"><i class="fa fa-map-marker"></i><?php echo e($store->address); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
        
            
                
                
            
            
                
                    
                
                
                    
                    
                
            
        
    </div>
</div>