<script type="text/javascript" src="<?php echo e(mix('/js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('custom-scripts'); ?>