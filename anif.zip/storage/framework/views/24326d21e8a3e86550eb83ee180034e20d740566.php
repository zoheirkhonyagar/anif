<div id="content">
    <div class="row container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>