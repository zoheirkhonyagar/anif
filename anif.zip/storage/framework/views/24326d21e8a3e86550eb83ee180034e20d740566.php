<div id="content">
    <?php echo $__env->yieldContent('content'); ?>
</div>