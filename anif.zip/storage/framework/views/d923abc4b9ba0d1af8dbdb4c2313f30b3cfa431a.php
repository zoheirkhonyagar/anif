<link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>">
<?php echo $__env->yieldContent('custom-styles'); ?>
