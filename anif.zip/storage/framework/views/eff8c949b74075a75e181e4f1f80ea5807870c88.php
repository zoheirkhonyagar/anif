<?php $__env->startSection('title'); ?>
    آنیف
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-header'); ?>

    <?php echo $__env->make('main.main-page.components.search-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('main.main-page.components.offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('main.main-page.components.best-restaurant', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>