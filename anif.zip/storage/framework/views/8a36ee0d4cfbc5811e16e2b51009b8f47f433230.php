<div class="row-content best-restaurant">
    <h2 class="title">برترین رستوران ها</h2>
    <div class="items offer-items">
        <?php $__currentLoopData = $storesWithRank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item offer-item">
                <div class="image-box">
                    <a href="#"><img src="/img/offer-item.jpeg" alt="image-box"></a>
                </div>
                <div class="caption-box">
                    <div class="info">
                        <div class="title"><a href="#"><?php echo e($store->name); ?></a></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
</div>