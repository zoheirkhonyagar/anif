<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('main.layout.header-styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('main.layout.header-scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

    <div id="app" class="wrapper">

        <?php echo $__env->make('main.layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('main.layout.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('main.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

    <?php echo $__env->make('main.layout.footer-scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>
