require("./main/js/scripts");

