require('./admin/js/bootstrap.min');
require('./admin/js/jquery.metisMenu');
require('./admin/js/jquery.slimscroll.min');
require('./admin/js/rada');
require('./admin/js/pace.min');