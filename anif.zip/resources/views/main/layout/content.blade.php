<div id="content">
    <div class="row container">
        @yield('content')
    </div>
</div>