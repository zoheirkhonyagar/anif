<div id="content">
    @yield('content')
</div>