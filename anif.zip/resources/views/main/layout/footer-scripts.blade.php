<script type="text/javascript" src="{{ mix('/js/app.js') }}"></script>
@yield('custom-scripts')