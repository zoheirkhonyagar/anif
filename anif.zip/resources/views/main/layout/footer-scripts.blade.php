<script src="/js/app.js"></script>
@yield('custom-scripts')