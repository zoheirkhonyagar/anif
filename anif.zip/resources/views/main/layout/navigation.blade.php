<div class="nav">
    <nav class="container">
        <div class="user-account">
            <i class="fa fa-user-circle-o fa-3x" aria-hidden="true"></i>
            <h3 class="sign-text"><a class="sign-in" href="#">ورود</a>/<a class="sign-up" href="#">ثبت نام</a> </h3>
        </div>
        <div class="logo">
            <img src="/img/anifLogoWeb.png" alt="آنیف">
        </div>
    </nav>
</div>