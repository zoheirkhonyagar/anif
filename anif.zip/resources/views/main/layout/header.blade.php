<header>
    @include('main.layout.navigation')
    @yield('custom-header')
</header>