<link rel="stylesheet" href="{{ mix('/css/app.css') }}">
@yield('custom-styles')
