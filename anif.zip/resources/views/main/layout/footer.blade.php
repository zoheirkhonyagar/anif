<footer>
    <div class="container">
        <div class="footer-widget">
            <div class="menu">
                <ul>
                    <li><a href="#">درباره ما</a></li>
                    <li><a href="#">تماس با ما</a></li>
                    <li><a href="#">قوانین</a></li>
                    <li><a href="#">سوالات متداول</a></li>
                </ul>
            </div>
            <div class="social">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook fa-2x"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram fa-2x"></i></a></li>
                    <li><a href="#"><i class="fa fa-telegram fa-2x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="line">
            <hr>
        </div>
        <div class="copy-right">
            <p>تمامی حقوق این سایت مربوط به شرکت ماورا با نام تجاری آنیف میباشد</p>
        </div>
    </div>
</footer>