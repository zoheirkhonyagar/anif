<div class="wrapper wrapper-content">
    @yield('content')
</div>
