<div class="footer">
    <div>
        <strong>کلیه حقوق محفوظ است</strong>
        1395-1397 &copy; <a href="#" target="_blank">لینک کپی رایت</a>
    </div>
</div>