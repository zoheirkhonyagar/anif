<div class="row border-bottom">
    <nav class="navbar navbar-static-top" role="navigation">

        @include('admin.layout.navbar.navbar-header')
        @include('admin.layout.navbar.navbar-left')

    </nav>
</div>