<script src="{{ mix('/js/admin/admin.js') }}"></script>
@yield('custom-scripts')