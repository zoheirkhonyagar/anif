<div class="navbar-header">
    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#">
        <i class="fa fa-bars">
        </i>
    </a>
    <form role="search" class="navbar-form-custom" action="search_results.html">
        <div class="form-group">
            <input type="text" placeholder="جستجو" class="form-control" name="top-search" id="top-search">
        </div>
    </form>
</div>