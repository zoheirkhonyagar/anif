@extends('admin.master')

@section('title')
    پنل مدیریت آنیف
@endsection

@section('content')

    @include('admin.dashboard.components.components')

@endsection