<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AnifPositions extends Model
{
    protected $guarded = [];
}
