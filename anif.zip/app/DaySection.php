<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DaySection extends Model
{
    protected $guarded = [];
}
